class UnaryDemo{
public static void main(String args[]){

	int a = 10;
	//++a;
	//System.out.println(a++); // 10
	//System.out.println(a); // 11

	//int b = 10;
	//System.out.println(++b); // 11
	//System.out.println(b); // 11


	int x = a++ + ++a;
	System.out.println(x);  // 21   22   23 

int arr[] = {10,20,30};
System.out.println(arr[0+1]);

//int size = sc.nextInt();
//int arr1[] = new int[size];



/*
int a = 10;

	10 constant value = no operator
*/












}
}