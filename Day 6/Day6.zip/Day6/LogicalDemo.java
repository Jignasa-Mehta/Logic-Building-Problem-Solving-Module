class LogicalDemo{
public static void main(String args[]){

/*int i =8;
if((i>5)&&(++i>11)){

System.out.println("IF block");
}
else{

System.out.println("else block");
}
System.out.println(i);
*/

int i =8;

if((i<5)||(i>11)&&(++i==8)){

System.out.println("IF block");
}
else{

System.out.println("else block");

}
System.out.println(i);







}
}
