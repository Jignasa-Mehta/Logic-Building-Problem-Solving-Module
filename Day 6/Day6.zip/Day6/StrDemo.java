class StringDemo{
public static void main(String args[]){


	/*int a = 10;
	a=20;

	String s = "ABC";
	s = "XYZ";

	String s1 = "XYZ";
	String s2 = "pQr";*/
	
	//System.out.println(s);
	//System.out.println(s1);

	//System.out.println(s == s1);
	//System.out.println(s2 == s1);

	//System.out.println(s.hashCode());
	//System.out.println(s1.hashCode());
	//System.out.println(s2.hashCode());



	//String s3 = new String("XYZ");
	//String s4 = new String("XYZ");
	//System.out.println(s3);


	//System.out.println(s2 == s3);
	//System.out.println(s3.equals(s));
	//System.out.println(s3.concat(s2));
	 
	//s3 = s3.concat(s2);
	//System.out.println(s3);
	//System.out.println(s3.length());
	
	
		
	String s3 = new String("XYZ");
	String s4 = new String("XYZ");
	System.out.println(s4 == s3);
	System.out.println(s3.equals(s4));
	















}


}