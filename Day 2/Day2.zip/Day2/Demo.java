
class TestNew{
	public static void main(String arg[]){

	int $a =10;
	//int b%b =10;	
	int ABC = 20;

	//int PUBLIC = 100;
	//int PUBLIC = 200;

	/*
	int PUBLIC;
	int PUBLIC;
	PUBLIC = 100;
	*/
	
	System.out.println("Hello CDAC Mumbai");
	System.out.println(ABC);
	
	System.out.println(PUBLIC);
	} 

}


