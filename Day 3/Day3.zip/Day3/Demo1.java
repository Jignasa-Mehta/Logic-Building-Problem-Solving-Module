class Demo1{

 public static void main(String[] Args){
	int a = 10;
	/*
	if(a>50){
		System.out.println("if block ");
	}
	else {
		System.out.println("else block ");
	}
	*/
	/*
	if(a==50){
		System.out.println("if block ");
	}
	else if(a>50){
		System.out.println("if-else block ");
	}
	//System.out.println("in main() ");  error : else Without if
	else{
		System.out.println("else block ");
	}
	*/

	System.out.println("in main() ");
	
	} 


}