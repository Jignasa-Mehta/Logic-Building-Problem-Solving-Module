class Demo{

	int a = 10;
	float b = 20.0f;
  
	static int var1;
	// contructors
	Demo(){
	System.out.println("Inside 0 para contru.");
	a = 100;
	b = 200.0f;
	}
	Demo(int a1){
	System.out.println("Inside 1 para contru.");
	a = a1;
	
	}
	//init block
	{
	System.out.println("Inside INIT block.");
	a = 1000;
	b = 2000.0f;
	var1 = 5000;
	}
	// static block
	static {
		System.out.println("Inside Static block.");
		var1 = 5;
		//a = 10000;  error : non-static var
	}
	public static void main(String[] Args){
		Demo obj = new Demo();
		Demo obj1 = new Demo(8);

		//System.out.println(obj.a);
		//System.out.println(obj.var1);
	} 


}