class Demo2{

 public static void main(String[] Args){
	//float a = 5.0f;  float, double &  long not allowed

	//int a = 5 ; 
/*
btye, short, int, char, String
*/	
	/*
	switch(a){
	//case 5.0f:  error : poosible lossy converiosn
	case 5:
		System.out.println("case 5");
		break;

	case 10:
		System.out.println("case 10 ");
		break;

	default :
		System.out.println("default");
		break;
	}

	*/
// ----------------------------------------------------------------
	/*char c = 'd';
	switch(c){
	
	case 'a':
		System.out.println("case a");
		break;

	case 'b':
		System.out.println("case b ");
		break;

	default :
		System.out.println("default");
		break;
	
	}*/
// ------------------------------------------------------------
	//char c = 'a';  // ASCII value of a is 97
	/*
	int c = 10;
	switch(c + c){
	
	case 'a':
		System.out.println("case a");
		break;

	case 20:
		System.out.println("case 20 ");
		break;
	case 30:
		System.out.println("case 30 ");
		break;
	case 194:
		System.out.println("case 30 ");
		break;

	default :
		System.out.println("default");
		break;
	
	}
	*/

	
// ---------------------------------------------------------------

	/*int c = 10;
	switch(c){
	
	case 20:
		System.out.println("case 20 ");
		break;
	case 30:
		System.out.println("case 30 ");
		break;
	case 10:
		System.out.println("case 10 ");
		break;
	
	default :
		System.out.println("default");
		break;

	
	
	}*/

//-----------------------------------------------

	int c = 10;
	switch(c){ 

	}


	System.out.println("in main() ");
	
	} 


}