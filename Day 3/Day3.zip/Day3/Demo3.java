class Demo3{

	public static void main(String args[]){
	
	/*
	for(int i=1; i<5 ; i++) {
		System.out.println("Hello " + i);
	}

	int i ; 
	for( i=1; i<5 ; ++i) {
		System.out.println("HII " + i);
	}*/

	/*int i,j;
	for(i=1, j = 2 ; i<5; i++,j++) {
		System.out.println("Hello " + i + " "+ j);
	}*/

	/* unreachable statement
	for(int i=1; false; i++) {
		System.out.println("Hello " + i);
	}*/

	/*for(int i=1; i==10 ; i++) {
		System.out.println("Hello " + i);
	}*/


	
	/*
	int i = 10;
	for( ; i==10 ; i++) {
		System.out.println("Hello " + i);
	}*/
	/*infinite loop
	for(int i=1; ; i++) {
		System.out.println("Hello " + i);
	}*/

	/*infinite loop
	for(; ; ) {
		System.out.println("Hello ");
	}*/

	//System.out.println("In Main()");


	/*for(int i=1; i<10 ; i+=2) {
		System.out.println("Hello " + i);
	}*/
	
	//for(int i=1; i<5 ; i++);

	for(int i=1; i<5 ; i++)
		System.out.println("Hello ");

	
	System.out.println("In Main()");
	}



}